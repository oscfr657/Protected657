from django.contrib import admin
from .models import ProtectedFile


admin.site.register(ProtectedFile)
